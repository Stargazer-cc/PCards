# 时间线示例

```timeline-labeled
[line-3, body-2]
date: 2024-01-01
title: 看了一部电影
content: 
    ```movie-card
    title: 盗梦空间
    director: 克里斯托弗·诺兰
    year: 2010
    description: 在这部科幻动作片中，一位经验丰富的盗梦者必须完成一个看似不可能的任务。
    tags: #科幻 #动作 #经典
    cover: https://example.com/inception.jpg
    meta.主演: 莱昂纳多·迪卡普里奥
    meta.评分: 9.3
    ```
date: 2024-02-02
title: 听了一张专辑
content:
    ```music-card
    title: 七里香
    artist: 周杰伦
    year: 2004
    description: 周杰伦第五张专辑，融合中国风与现代流行音乐。
    tags: #华语 #流行
    cover: https://example.com/qilixiang.jpg
    ```
```